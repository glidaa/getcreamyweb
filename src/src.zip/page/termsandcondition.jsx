import React from "react";

export default function Termsandcondition() {
  return <div>Termsandcondition</div>;
}
